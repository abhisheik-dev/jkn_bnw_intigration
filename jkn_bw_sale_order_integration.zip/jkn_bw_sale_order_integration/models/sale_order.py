from odoo import models, api
import requests
from odoo.exceptions import UserError

class SaleOrder(models.Model):
    _inherit = 'sale.order'  # Ensure this correctly inherits 'sale.order'

    def send_to_bnw(self):
        """Send Sale Order to B&W API"""
        for record in self:
            if record.warehouse_id.name != 'B&W Salaya':
                continue

            sale_order_data = {
                "sale_order": {
                    "ref_doc_no": record.name,
                    "ref_po": record.client_order_ref or "",
                    "site_name": record.partner_id.name,
                    "address": f"{record.partner_shipping_id.street or ''}, "
                               f"{record.partner_shipping_id.city or ''}, "
                               f"{record.partner_shipping_id.zip or ''}",
                    "sale_order_details": [
                        {
                            "product_ref_code": line.product_id.default_code,
                            "qty": line.product_uom_qty,
                        } for line in record.order_line
                    ]
                }
            }

            url = "http://s.bwlogistics.co.th:2533/sale-order/"
            headers = {
                "Authorization": "Bearer 3116DF5E-25FB-45D4-ABE2-9ACDB8ADD970",
                "Content-Type": "application/json",
            }

            try:
                response = requests.post(url, json=sale_order_data, headers=headers)
                response.raise_for_status()
                response_data = response.json()
                record.message_post(
                    body=f"Order {record.name} successfully sent to B&W. Response: {response_data}"
                )
            except requests.exceptions.RequestException as e:
                record.message_post(body=f"Failed to send order {record.name} to B&W. Error: {str(e)}")
                raise UserError(f"Failed to send order {record.name} to B&W. Error: {str(e)}")
