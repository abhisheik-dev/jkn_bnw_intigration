{
    'name': 'JKN and B&W Sale Order Integration',
    'version': '4.0',
    'summary': 'Integrates Sale Orders with B&W System',
    'description': 'A custom module to send confirmed sale orders with the B&W Salaya warehouse to an external API.',
    'category': 'Sales',
    'author': 'Abhisheik Sharma JKN Global group 5 dec 2024',
    'depends': ['sale'],
    'data': [],  # No additional data files required for this module
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}
